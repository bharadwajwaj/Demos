﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileReadWrite_demo
{
    class Program
    {
        static void WriteContent(List<string> lines, string filePath)
        {
            FileStream fileStream = null;
            StreamWriter streamWriter = null;

            try
            {
                // creating file stream
                fileStream = new FileStream(filePath, FileMode.Create);
                streamWriter = new StreamWriter(fileStream);
                foreach (var ln in lines)
                {
                    streamWriter.WriteLine(ln);
                }

            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                streamWriter.Close();
                fileStream.Close();

            }
            //streamWriter.Close();
            //fileStream.Close();
        }


        static List<string> ReadContent(string filePath)
        {
            FileStream fileStream = null;
            StreamReader streamReader = null;
            List<string> line = new List<string>();
            try
            {
                fileStream = new FileStream(filePath, FileMode.Open);
                streamReader = new StreamReader(fileStream);

                while (!streamReader.EndOfStream)
                {
                    string ln = streamReader.ReadLine();
                    line.Add(ln);
                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                streamReader.Close();
                fileStream.Close();

            }
            return line;


            //streamReader.Close();
            //fileStream.Close();
        }
        static void Main(string[] args)
        {
            string path = @"../../Abc.txt";  // relative , absolute path
            List<string> lines = new List<string>
            {
                "This is my first line",
                "This is my second line",
                "And this is my last line"

            };
            WriteContent(lines, path);

            List<string> c_lines = ReadContent(path);
            foreach (var item in c_lines)
            {
                Console.WriteLine(item);
            }

            Console.ReadKey();



        }
    }
}
