﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileReadWrite
{

    class Employee
    {
        public int empID { get; set; }
        public string empName { get; set; }
        public double Salary { get; set; }



        static void WriteContent(List<Employee> employee, string filePath)
        {
            FileStream fileStream = null;
            BinaryWriter binaryWriter = null;
            try
            {
                fileStream = new FileStream(filePath, FileMode.Create);
                binaryWriter = new BinaryWriter(fileStream);
                foreach (var emp in employee)
                {
                    binaryWriter.Write(emp.empID);
                    binaryWriter.Write(emp.empName);
                    binaryWriter.Write(emp.Salary);
                }

                //streamWriter.WriteLine();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                binaryWriter.Close();
                fileStream.Close();
            }
        }
        static List<Employee> ReadContent(string filePath)
        {
            FileStream fileStream = null;
            BinaryReader binaryReader = null;
            List<Employee> emps = new List<Employee>();
            try
            {
                fileStream = new FileStream(filePath, FileMode.Open);
                binaryReader = new BinaryReader(fileStream);
                try
                {
                    while (true)
                    {
                        Employee emp = new Employee();
                        emp.empID = binaryReader.ReadInt32();

                        emp.empName = binaryReader.ReadString();
                        emp.Salary = binaryReader.ReadDouble();
                        emps.Add(emp);
                    }
                }
                catch (Exception ex)
                {

                }
            }

            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                binaryReader.Close();
                fileStream.Close();

            }
            return emps;
        }
        static void Main(string[] args)
        {

            //string path = @"C:\temp\MyFolder1\Abc.txt";  //absolute path = specific path.... 
            string path = @"Abc.txt";    //relative path
            List<Employee> c_emp = new List<Employee>
            {
                new Employee{ empID=101 , empName="Bharadwaj",Salary=500000}

            };
            WriteContent(c_emp, path);
            List<Employee> emp = ReadContent(path);
            foreach (var item in emp)
            {
                Console.WriteLine(item.empID);
                Console.WriteLine(item.empName);
                Console.WriteLine(item.Salary);
            }
            Console.ReadKey();
        }
    }
}
