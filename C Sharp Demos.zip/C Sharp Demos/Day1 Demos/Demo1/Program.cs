﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Clslib_calculator;

namespace Demo1
{
    class Program
    {
        static void Main(string[] args)
        {
            Calculator calculator = new Calculator();
            Console.WriteLine("Enter First Number: ");
            int n1 = int.Parse(Console.ReadLine());
            Console.Write("Enter Second Number: ");
            int n2 = int.Parse(Console.ReadLine());

            int res = calculator.Add(n1, n2);
            Console.WriteLine("Result is: " + res);
            //Console.WriteLine("Hi");
           
            Console.ReadKey();
        }
    }
}
