﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Clslib_calculator
{
    public class Calculator
    {
        public int Add(int n1, int n2)
        {
            return n1 + n2;
        }
    }
}
