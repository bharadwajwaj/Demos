﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    public enum HighestQua { undergraduate = 1, graduate, postgraduate}
    class student
    {
        int rollNo;
        string name;
        double feesPaid;
        DateTime dob;
        HighestQua HQ;

        public student(int rollNo, string name, double feesPaid, DateTime dob, HighestQua HQ)
        {
            this.rollNo = rollNo;
            this.name = name;
            this.feesPaid = feesPaid;
            this.dob = dob;
            this.HQ = HQ;
        }

         public string GetstudentDetails()
        {
            return "rollNo: " + rollNo + ",Name: " + name + ",feesPaid: " + feesPaid + ",dob: " + dob + "HighestQua " + HQ;
        }

    }
}
