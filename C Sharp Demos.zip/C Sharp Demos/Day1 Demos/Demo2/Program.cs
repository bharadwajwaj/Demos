﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter RollNo : ");
            int rNo = int.Parse(Console.ReadLine());
            Console.Write("Enter Name : ");
            string nm = Console.ReadLine();
            Console.Write("Enter feesPaid : ");
            double fp = double.Parse(Console.ReadLine());
            Console.Write("Enter DOB(mm/dd/yyyy): ");
            DateTime DOB = DateTime.Parse(Console.ReadLine());
            Console.Write("select your grade:1.graduate 2.postgraduate 3.grade");
            HighestQua HQ = (HighestQua)int.Parse(Console.ReadLine());

            student student = new student(rNo, nm, fp, DOB, HQ);

            Console.WriteLine(student.GetstudentDetails());
            Console.ReadLine();

        }
    }
}
