﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization.Formatters.Binary;
using System.Runtime.Serialization.Formatters.Soap;

namespace SerializationDemo
{
    class Program
    {
        static void SerializeEmployees(List<Employee> employees, FileStream fileStream)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(fileStream, employees);
            fileStream.Close();
        }

        static (List<Employee> DeserializeEmployees(FileStream fileStream)
        {
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(fileStream, employees);
            fileStream.Close();
            return employees;
        }

        static void Main(string[] args)
        {
        FileStream fileStream1 = new FileStream("Employees.bin", FileMode.Create);

            List<Employee> employees = new List<Employee>
            {
                new Employee{ Id = 101, Name = "umesh", Salary = 30002},
            }
        }
    }
}
