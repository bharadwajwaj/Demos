﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShareAssDemo
{
    public class MyCalc
    {
        public int Result { get; set; }

        public void Add(int n1, int n2)
        {
            Result = n1 + n2;
        }

        public void Sub(int n1, int n2)
        {
            Result = n1 - n2;
        }

    }
}
