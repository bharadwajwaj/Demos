﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
namespace ShareAssDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            string path = @"C: \Users\buppalan\bharadwaj172476\dot net\Day1 Demos\Demo1\bin\Debug\Clslib_calculator.dll";
            Assembly assembly = Assembly.LoadFrom(path);
            Type[] types = assembly.GetTypes();
            foreach(Type t in types)
            {
                Console.WriteLine(t.FullName); //MyCalc | Employee
                foreach(MethodInfo mt in t.GetMethods())
                {
                    Console.WriteLine(mt.ReturnType+" "+mt.Name);
                }
            }
            Console.ReadKey();
        }
    }
}
