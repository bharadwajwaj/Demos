﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using EMS_BAL;
using EMS_Entities;
using EMS_Exceptions;

namespace Employee_Management_System
{
    class Program
    {
        static void Main(string[] args)
        {
            EmployeeBAL employeeBAL = new EmployeeBAL();
            try
            {


                Employee emp = new Employee
                {
                    EmpId = 1001,
                    DOJ = DateTime.Now.AddDays(-2),
                    Salary = 12000,
                    EmpName = "Bharadwaj"
                };
                employeeBAL.Add(emp);
                Console.WriteLine("Inserted..");
                List<Employee> employees = employeeBAL.GetAll();
                foreach (var item in employees)
                {
                    Console.WriteLine(item); // EMS_Entities.Employee
                }
                //----------------------------------

                emp = new Employee
                {
                    EmpId = 1002,
                    DOJ = DateTime.Now.AddDays(-2),
                    Salary = 12000,
                    EmpName = "Bharadwaj"
                };
                employeeBAL.Add(emp);
                Console.WriteLine("Updated..");
                employees = employeeBAL.GetAll();
                foreach (var item in employees)
                {
                    Console.WriteLine(item); // EMS_Entities.Employee
                }
            }
            catch (EmployeeValidationException ex3)
            {
                Console.WriteLine(ex3.Message);
            }
            catch (EmployeeNotFoundException ex4)
            {
                Console.WriteLine(ex4.Message);
            }
            catch (Exception ex5)
            {
                Console.WriteLine(ex5.Message);
            }

            Console.ReadKey();
        }

    }
}
