﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter RollNo : ");
            int rNo = int.Parse(Console.ReadLine());
            Console.Write("Enter Name : ");
            string nm = Console.ReadLine();
            Console.Write("Enter feesPaid : ");
            double fp = double.Parse(Console.ReadLine());
            Console.Write("Enter DOB(mm/dd/yyyy): ");
            DateTime DOB = DateTime.Parse(Console.ReadLine());
            Console.WriteLine("Select your grade: ");
            HighestQua HQ = (HighestQua)int.Parse(Console.ReadLine());

            student student = new student(rNo, nm, fp, DOB, HQ);

            Console.WriteLine(student.GetstudentDetails());

            //int x1 = 1;    //C#
            //Int32 x2 = 1;  //C#, VB.NET, JB.NET, in any lang

            //string str1;
            //String str2;   //Wrapper Class

            //double d1;
            //Double d2;     //Wrapper Class

            //float f1;
            //Single f2;

            //short s1;
            //Int16 s2;

            //long l1;
            //Int64 l2;

            //int? n = null;
            ////Nullable<int>n = null;
            //if (n == null)
            //{
            //    Console.WriteLine("n is null");
            //}
            //else
            //{
            //    Console.WriteLine("n is not null");
            //}
            Console.ReadKey();
        }
    }
}
