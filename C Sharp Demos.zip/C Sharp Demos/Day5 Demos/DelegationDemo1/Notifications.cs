﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegationDemo1
{
    delegate void NotificationDelegate(string message);

    class Notifications
    {
        public void SendSMS(string message)
        {
            //Consider that this code is to send SMS
            Console.WriteLine(message);
        }

        public void SendMail(string message)
        {
            //Consider that this code is to send Mail
            Console.WriteLine(message);
        }

        public void SendVoiceCall(string message)
        {
            //Consider that this code is to send VoiceCall
            Console.WriteLine(message);
        }
    }
}
