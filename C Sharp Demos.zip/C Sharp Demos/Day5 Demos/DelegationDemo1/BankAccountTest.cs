﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegationDemo1
{
    class BankAccountTest
    {
        static void Main(string[] args)
        {
            NotificationDelegate notifDel = new NotificationDelegate(Notifications.SendMail);
            BankAccount bankAccount = new BankAccount(102, 10000, notifDel);

            bankAccount.with(1000);
            bankAccount.Depo(200);

            Console.ReadKey();
        }
    }
}
