﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegationDemo
{
    //Step-1: Defining Delegate
    public delegate int CalcDelegate(int n1, int n2);

    public class Calc
    {
        public int Add(int n1, int n2)
        {
            return n1 + n2;
        }
        public int Sub(int n1, int n2)
        {
            return n1 - n2;
        }
        public int Mul(int n1, int n2)
        {
            return n1 * n2;
        }
        public int Div(int n1, int n2)
        {
            return n1 / n2;
        }
    }
}
