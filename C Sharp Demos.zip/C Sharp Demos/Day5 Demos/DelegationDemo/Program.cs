﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegationDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Calc calc = new Calc();
            //Step-2: Creating instance of Delegate
            //CalcDelegate calcDelegate = new CalcDelegate(calc.Add);
            //calcDelegate += new CalcDelegate(calc.Sub);
            //calcDelegate += new CalcDelegate(calc.Div);
            CalcDelegate del1 = new CalcDelegate(calc.Add);
            CalcDelegate del2 = new CalcDelegate(calc.Mul);
            CalcDelegate del3 = new CalcDelegate(calc.Sub);
            CalcDelegate del = (CalcDelegate)Delegate.Combine(del1, del2, del3);
            //del(3, 2);

            CalcDelegate d1 = (CalcDelegate)Delegate.Remove(del, del2);
            d1(3, 2);

            //Step-3: Invoking Delegate
            //int res = calcDelegate(2, 3);
            //calcDelegate -= new CalcDelegate(calc.Sub);
            //calcDelegate(2, 3);
            //Console.WriteLine("Result is : " + res);
            Console.ReadKey();
        }
    }
}
