﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo1
{
    class Employee
    {
        protected int empID;
        protected string empName;
        protected double salary, gs, ns, pf;
        protected Employee(int empID, string empName, double salary)
        {
            this.empID = empID;
            this.empName = empName;
            this.salary = salary;
        }
        public virtual void CalcSalary()
        {
            pf = salary * 0.12;
            gs = salary + pf;
            ns = gs - pf;
        }
    }
    class Manager : Employee{
        double incentives;

        public Manager(int empID, string empName, double salary):base(empID, empName, salary)
        {
            incentives = 5000;
            //base.empID = empID;
            //base.empName = empName;
            //base.salary = salary;
        }
        public override void CalcSalary()
        {
            base.CalcSalary();
            gs = gs + incentives;
            ns = gs - pf;
        }
    }
}
