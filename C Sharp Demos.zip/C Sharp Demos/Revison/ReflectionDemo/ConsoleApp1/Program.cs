﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
using System.IO;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Enter Asm Path: ");
            string asmPath = @"C:\Users\buppalan\bharadwaj172476\M2\C Sharp Demos\Revison\ReflectionDemo\ClassLibrary1\bin\Debug\ClassLibrary1.dll"; /*Console.ReadLine();*/
            
            Assembly asm = Assembly.LoadFrom(asmPath);

            foreach(Type type in asm.GetTypes())
            {
                Console.WriteLine("\nMethods from"+type.FullName);
                foreach(MethodInfo m1 in type.GetMethods())
                {
                    Console.WriteLine(m1.GetParameters());
                }
                Console.WriteLine("\nProperties from" + type.FullName);
                foreach (PropertyInfo p1 in type.GetProperties())
                {
                    Console.WriteLine(p1.ToString());
                }
                Console.WriteLine("\nFields from" + type.FullName);
                foreach (FieldInfo f1 in type.GetFields())
                {
                    Console.WriteLine(f1.ToString());
                }
            }
            Console.ReadKey();
        }
    }
}
