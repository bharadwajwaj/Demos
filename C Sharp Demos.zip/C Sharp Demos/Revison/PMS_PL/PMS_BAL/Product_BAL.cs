﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_DAL;
using PMS_Entities;
using PMS_Exceptions;
using System.Text.RegularExpressions;

namespace PMS_BAL
{
    public class Product_BAL
    {
        Product_DAL dal = new Product_DAL();                           //taking reference of DAL
        public bool IsValid(Product product)       //taking class entity ... (Product product)
        {
            bool valid = true;
            StringBuilder stringBuilder = new StringBuilder();   //for displaying error message

             

            // Create a bool variable and use the Regex.IsMatch static method which returns true if a specific value matches a specific pattern  
            if( !Regex.IsMatch(product.Email, @"^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$"))
            {
                valid = false;
                stringBuilder.Append("\nThis is invalid email address"+Environment.NewLine);
            }

            if(product.Price <100 || product.Price >50000)
            {
                valid = false;
                stringBuilder.Append("\nProduct price should be in range 101 to 50000" + Environment.NewLine);
            }
            if (product.ExpDate < DateTime.Now)       //Expiry date must be a future date
            {
                stringBuilder.Append("\nProduct is already expired");
                valid = false;
            }
            if (Regex.IsMatch(product.Name, @"^[{L} .-]+$"))       //product name 
            {
                stringBuilder.Append("\nProduct name should not contain special characters"+ Environment.NewLine);
                valid = false;
            }
            
            if(!valid)
            {
                throw new ProductValidationException(stringBuilder.ToString());
            }
            return valid;
        }

        public List<Product> GetAll()
        {
            return dal.SelectAll();
        }

        public void Add(Product product)
        {
            try
            {
                if(IsValid(product))
                {
                    dal.Insert(product);
                }
               
            }
            catch(ProductValidationException)
            {
                throw;
            }
            catch(Exception ex1)
            {
                throw;
            }
        }

        public void Edit(Product product)
        {
            try
            {
                if (IsValid(product))
                {
                    dal.Update(product);
                }

            }
            catch (ProductValidationException)
            {
                throw;
            }
            catch (Exception ex1)
            {
                throw;
            }
        }

        public void Delete(int id)
        {
            try
            {
                    dal.Delete(id);           
            }
            catch (ProductNotFoundException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }

        public Product Find(int id)
        {
            return dal.Search(id);
        }
    }
}
