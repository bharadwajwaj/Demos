﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using PMS_DAL;
using PMS_Entities;
using PMS_Exceptions;
namespace PMS_BAL
{
    public class ProductBAL
    {
        ProductDAL dal = new ProductDAL();

        public bool IsValid(Product product)
        {
            bool valid = true;
            StringBuilder stringBuilder = new StringBuilder();

            if(!Regex.IsMatch(product.Email, @"^\w+@[a-zA-Z_]+?\.[a-zA-Z]{2,3}$"))
            {
                valid = false;
                stringBuilder.Append("This is invalid Email Address"+Environment.NewLine);
            }
            if(product.Name == string.Empty)
            {
                valid = false;
                stringBuilder.Append("Product Name Required" + Environment.NewLine);
            }
            if(product.Price <=100 || product.Price >=200)
            {
                valid = false;
                stringBuilder.Append("Enter Valid Price" + Environment.NewLine);
            }

            if(!valid)
            {
                throw new ProductValidationException(stringBuilder.ToString());
            }
            return valid;
        }

        public List<Product> GetAll()
        {
            return dal.SelectAll();
        }

        public void Add(Product product)
        {
            try
            {
               if(IsValid(product))
                {
                    dal.Insert(product);
                }
            }
            catch(ProductValidationException)
            {
                throw;
            }
            catch(Exception)
            {

            }
        }

        public void Edit(Product product)
        {
            try
            {
                if (IsValid(product))
                {
                    dal.Update(product);
                }
            }
            catch (ProductValidationException)
            {
                throw;
            }
            catch (Exception)
            {

            }
        }

        public void Delete(int id)
        {
            try
            {
                dal.Delete(id);
            }
            catch (ProductNotFoundException)
            {
                throw;
            }
            catch (Exception)
            {
                throw;
            }
        }
        public Product Find(int id)
        {
            Product search = null;
            try
            {
                ProductDAL product = new ProductDAL();
                search = product.Search(id);
                dal.Search(id);
                
            }
            catch(ProductNotFoundException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch(Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            Console.ReadKey();

            return dal.Search(id);
        }
    }
}
