﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_BAL;
using PMS_Entities;
using PMS_Exceptions;

namespace PMS_PL
{
    class Program
    {
        static int PrintMenu()
        {
            Console.WriteLine("======Menu=====\n1.Add Product\n2.Update Product\n3.Delete Product\n4.Display All Products\n5.Search Product");
            Console.WriteLine("select Your Choice: ");
            int choice = int.Parse(Console.ReadLine());
            return choice;
        }

        static Product CreateProduct()
        {
            Product product = new Product();
            Console.WriteLine("Enter Product Details");

            Console.Write("Name: ");
            product.Name = Console.ReadLine();

            Console.Write("Price: ");
            product.Price = double.Parse(Console.ReadLine());

            Console.Write("Expiry Date (MM/DD/YYYY): ");
            product.ExpDate = Convert.ToDateTime(Console.ReadLine());

            Console.Write("Email: ");
            product.Email = Console.ReadLine();
            

            return product;
        }
        static void DisplayProducts(List<Product> prods)
        {
            foreach(var prd in prods)
            {
                Console.Write(prd);
                
            }
            
        }

        static void Main(string[] args)
        {

            try
            {

                ProductBAL bal = new ProductBAL();
                string choice1;
                do
                {
                    int choice = PrintMenu();
                    Product prod = null;
                    int id = 0;

                    switch (choice)
                    {
                        case 1:
                            prod = CreateProduct();
                            bal.Add(prod);
                            Console.WriteLine("Inserted");
                            break;

                        case 2:
                            prod = CreateProduct();
                            bal.Edit(prod);
                            Console.WriteLine("Updated");
                            break;

                        case 3:

                            Console.Write("Enter Id of product to be deleted: ");
                            int Id = int.Parse(Console.ReadLine());
                            bal.Delete(Id);
                            Console.WriteLine("Deleted");
                            break;
                        case 4:
                            List<Product> prods = bal.GetAll();
                            DisplayProducts(prods);
                            break;
                        case 5:
                            Console.WriteLine("Enter the id to be searched");
                            Id = int.Parse(Console.ReadLine());
                            bal.Find(Id);
                            Console.WriteLine(prod);
                            break;
                        default:
                            Console.WriteLine("Invalid Choice: ");
                            break;
                    }

                    Console.WriteLine("Do you want to contiue(y/n)?");
                    choice1 = Console.ReadLine();
                } while (choice1 == "y" || choice1 == "Y");
            }
            catch (ProductValidationException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch (ProductNotFoundException ex1)
            {
                Console.WriteLine(ex1.Message);
            }
            catch (Exception ex1)
            {
                Console.WriteLine(ex1.Message);
            }

                    Console.ReadKey();
        }
    }
}
