﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_Entities;
using PMS_Exceptions;

namespace PMS_DAL
{
    public class Product_DAL
    {
        List<Product> products = new List<Product>();    //create List

        public List<Product> SelectAll()                 //returning list created
        {
            return products;
        }

        public void Insert(Product product)
        {
            try
            {
                products.Add(product);
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void Update(Product product)
        {
            try
            {
                //1. LINQ expression
                //var prd = (from p in products             //products is collection  product is object
                //          where p.ID == product.ID
                //          select p).SingleOrDefault();    //returns collection which is converted to single value
           
                //2. Using Extension method and lambda
                var prd = products.SingleOrDefault(p => p.ID == product.ID);
                if (prd != null)
                {
                    prd.Name = product.Name;
                    prd.Price = product.Price;
                    prd.ExpDate = product.ExpDate;
                    prd.Email = product.Email;
                }
                else
                {
                    throw new ProductNotFoundException("Product with id:" + product.ID + "Not found");

                }

            }
            catch (ProductNotFoundException ex1)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

        public void Delete(int id)
        {
            try
            {
                

                //2. Using Extension method and lambda
                var prd = products.SingleOrDefault(p => p.ID == id);
                if (prd != null)
                {

                    products.Remove(prd);
                }
                else
                {
                    throw new ProductNotFoundException("Product with id:" + id + "Not Found");

                }


            }
            catch(ProductNotFoundException ex1)
            {
                throw;
            }
            catch (Exception ex2)
            {
                throw;
            }
        }

        public Product Search(int id)
        {
            var prd = products.SingleOrDefault(p => p.ID == id);
            return prd;
        }
    }
}
