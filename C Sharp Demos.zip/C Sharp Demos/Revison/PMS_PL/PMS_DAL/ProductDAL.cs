﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PMS_Entities;
using PMS_Exceptions;

namespace PMS_DAL
{
    public class ProductDAL
    {
        List<Product> products = new List<Product>();

        public List<Product> SelectAll()
        {
            return products;
        }

        public void Insert(Product product)
        {
            try
            {
                products.Add(product);
            }
            catch(Exception ex)
            {
                throw;
            }
        }

        public void Update(Product product)
        {
            try
            {
                //1.Using LINQ Expression
                //var prd = (from p in products
                //           where p.Id == product.Id
                //           select p).SingleOrDefault();
                //prd.Name = product.Name;
                //prd.Price = product.Price;
                //prd.ExpDate = product.ExpDate;

                //2.Using Extension Method and lambda 

                var prd = products.SingleOrDefault(p => p.Id == product.Id);

                if(prd!= null)
                {
                    prd.Name = product.Name;
                    prd.Price = product.Price;
                    prd.ExpDate = product.ExpDate;
                }
               else
                {
                    throw new ProductNotFoundException("Product with Id: " + product.Id + "Not Found");
                }
            }
            catch(ProductNotFoundException ex1)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public void Delete(int Id)
        {
            try
            {
                //1.Using LINQ Expression
                //var prd = (from p in products
                //           where p.Id == product.Id
                //           select p).SingleOrDefault();
                //prd.Name = product.Name;
                //prd.Price = product.Price;
                //prd.ExpDate = product.ExpDate;

                //2.Using Extension Method and lambda 

                var prd = products.SingleOrDefault(p => p.Id == Id);
                if(prd!=null)
                {
                    products.Remove(prd);
                }
                else
                {
                    throw new ProductNotFoundException("Product with Id: " + Id + "Not Found");
                }
     
            }
            catch (ProductNotFoundException ex1)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
        }
        public Product Search(int Id)
        {
            try
            {
                var prd = products.SingleOrDefault(p => p.Id == Id);
                if(prd!=null)
                {
                    
                    return prd;
                }
                else
                {
                    throw new ProductNotFoundException("Product with Id: " + Id + "Not Found");
                }
            }
            catch (ProductNotFoundException ex1)
            {
                throw;
            }
            catch (Exception ex)
            {
                throw;
            }
        }

    }
}
