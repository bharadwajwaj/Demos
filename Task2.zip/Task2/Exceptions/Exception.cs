﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exceptions
{
    public class  EmpInvalidDataException: Exception
    {
          public EmpInvalidDataException(string sb)  //creating custom Exceptons
            : base(sb)
        {

        }
    }
    public class EmpDatabaseException : Exception
    {
        public EmpDatabaseException(string sb)
            : base(sb)
        {

        }
    }
}
