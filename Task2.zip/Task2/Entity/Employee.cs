﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entity
{
    public class Employee
    {
        public int EmpID { get; set; }

        public string Name { get; set; }

        public string Gender { get; set; }

        public string Position { get; set; }

        public int salary { get; set; }
    }
}
