﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Entity;
using Exceptions;
using BAL;
using System.Data;

namespace Task2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Employee emp = new Employee(); //Creating Employee object
        public MainWindow()
        {
            InitializeComponent();
            windowload();
        }
        void windowload()
        {
            try
            {

                DataTable dt = EmployeeBAL.RetrieveDetails(); //Retrieving the EmployeeDetails in a table
                data.ItemsSource = dt.DefaultView;

                Empid.Text = EmployeeBAL.employeid().ToString();

            }
            catch (EmpDatabaseException ex)
            {
                throw ex;
            }

            catch (EmpInvalidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void SubmitDetails(object sender, RoutedEventArgs e)
        {
            try
            {

                //Employee emp = new Employee();

                //emp.EmpID = int.Parse(Empid.Text.ToString());

                emp.Name = EmpName.Text.ToString();

                if (male.IsChecked == true)
                {
                    emp.Gender = "Male";
                }
                else if (female.IsChecked == true)
                {
                    emp.Gender = "Female";
                }

                emp.Position = position.SelectionBoxItem.ToString();

                emp.salary = int.Parse(Salary.Text.ToString());


                EmployeeBAL.SubmitDetails(emp);
                MessageBox.Show("successfully saved details");
                windowload();
                


            }
            catch (EmpInvalidDataException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }
        private void ExportToExcel(object sender, RoutedEventArgs e)   //Exporting to Excel Sheet
        {
            Microsoft.Office.Interop.Excel._Application app = new Microsoft.Office.Interop.Excel.Application();
            Microsoft.Office.Interop.Excel._Workbook workbook = app.Workbooks.Add(Type.Missing);
            Microsoft.Office.Interop.Excel._Worksheet worksheet = null;
            worksheet = workbook.Sheets["Sheet1"];
            worksheet = workbook.ActiveSheet;
            worksheet.Name = "Directory1";
            //
            Microsoft.Office.Interop.Excel.Range cellRange;

            // app.DisplayAlerts = false;
            //  app.Visible = false;


            DataTable dataTable = EmployeeBAL.RetrieveDetails();
            worksheet.Cells.Font.Size = 11;



            int rowcount = 1;
            for (int i = 0; i < dataTable.Columns.Count; i++) //taking care of Headers.  
            {
                worksheet.Cells[rowcount, i] = dataTable.Columns[i].ColumnName;
            }

            foreach (System.Data.DataRow row in dataTable.Rows) //taking care of each Row  
            {
                rowcount++;
                for (int i = 0; i < dataTable.Columns.Count; i++) //taking care of each column  
                {
                    worksheet.Cells[rowcount, i] = row[i].ToString();
                }
            }

            cellRange = worksheet.Range[worksheet.Cells[1, 1], worksheet.Cells[rowcount, dataTable.Columns.Count]];
            cellRange.EntireColumn.AutoFit();

            string path = @"D:\Users\buppalan\Downloads\Task2";
            //workbook.SaveAs(path, worksheet.Name);
            workbook.SaveAs(worksheet.Name, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Microsoft.Office.Interop.Excel.XlSaveAsAccessMode.xlExclusive, Type.Missing, Type.Missing, Type.Missing, Type.Missing, Type.Missing);

            // workbook.Close(); 
            app.Quit();
        }
       
    }
}
