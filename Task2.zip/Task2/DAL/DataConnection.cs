﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL
{
    class DataConnection
    {
        public static SqlCommand GenerateCommand()
        {

            try
            {

                SqlCommand cmd = null; //creating the null command

                //creating sql connection and storing the connection
                SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["Training"].ConnectionString);

                cmd = new SqlCommand();

                cmd.CommandType = CommandType.StoredProcedure; //selecting command type

                cmd.Connection = con; //opening the connection

                return cmd;
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
    }
}
