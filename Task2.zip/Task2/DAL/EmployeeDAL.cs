﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entity;
using Exceptions;
using System.Data.SqlClient;
using System.Data;

namespace DAL
{
    public class EmployeeDAL
    {
        public static List<Employee> Employees = new List<Employee>();  //creating a list of Employee Type 

        public static SqlCommand cmd = null;

        public static void SubmitDetails(Employee emp)
        {
            try
            {

                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "AddEmployee";


                cmd.Parameters.AddWithValue("@Name", emp.Name);
                cmd.Parameters.AddWithValue("@Gender", emp.Gender);
                cmd.Parameters.AddWithValue("@Position", emp.Position);
                cmd.Parameters.AddWithValue("@Salary", emp.salary);

                cmd.Connection.Open();

                int rowsaffected = cmd.ExecuteNonQuery();

                if (rowsaffected == 0)
                {
                    throw new EmpDatabaseException("Data is not added, Try Again.");
                }


            }

            catch (EmpDatabaseException ex)
            {
                throw ex;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                cmd.Connection.Close();
            }
        }

        public static DataTable RetrieveDetails()
        {
            try
            {
                DataTable dt = new DataTable();
                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "FetchEmployees";
                cmd.Connection.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    dt.Load(dr);
                    return dt;
                }

                throw new EmpDatabaseException("No data is available.");
            }
            catch (EmpDatabaseException ex)
            {
                throw ex;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                cmd.Connection.Close();
            }
        }
        public static int employeid()
        {
            try
            {


                cmd = DataConnection.GenerateCommand();

                cmd.CommandText = "FetchEmployees";




                cmd.Connection.Open();

                SqlDataReader dr = cmd.ExecuteReader();

                if (dr.HasRows)
                {
                    int x = 0;
                    while (dr.Read())
                    {
                        x = (int)dr["EmpID"];
                    }

                    return ++x;
                }

                throw new EmpDatabaseException("No data is available.");
            }
            catch (EmpDatabaseException ex)
            {
                throw ex;
            }

            catch (Exception ex)
            {
                throw ex;
            }

            finally
            {
                cmd.Connection.Close();
            }
        }
    }
}
