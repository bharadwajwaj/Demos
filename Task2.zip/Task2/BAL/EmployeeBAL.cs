﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL;
using Entity;
using Exceptions;
using System.Data;

namespace BAL
{
    public class EmployeeBAL
    {
        static StringBuilder sb = new StringBuilder();

        public static void SubmitDetails(Employee emp)
        {
            try
            {

                if (isvalid(emp))
                {
                    EmployeeDAL.SubmitDetails(emp);


                }
                else
                {
                    throw new EmpInvalidDataException(sb.ToString());
                }
            }
            catch (EmpDatabaseException ex)
            {
                throw ex;
            }

            catch (EmpInvalidDataException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        static bool isvalid(Employee emp)
        {
            try
            {

                bool valid = true;
                if (emp.Name == null)
                {
                    valid = false;
                    sb.Append("Employee name must not be null");
                }

                if (emp.Gender == null)
                {
                    valid = false;
                    sb.Append("Employee Gender must  be selected");
                }

                if (emp.Position == null)
                {
                    valid = false;
                    sb.Append("Employee possition must not be null");
                }

                if (emp.salary <= 0)
                {
                    valid = false;
                    sb.Append("Enter valid salary");
                }

                return valid;
            }
            catch (EmpDatabaseException ex)
            {
                throw ex;
            }

            catch (EmpInvalidDataException ex)
            {
                throw ex;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public static DataTable RetrieveDetails()
        {
            try
            {
                return EmployeeDAL.RetrieveDetails();
            }
            catch (EmpDatabaseException ex)
            {
                throw ex;
            }

            catch (Exception ex)
            {
                throw ex;
            }
        }
        public static int employeid()
        {
            return EmployeeDAL.employeid();
        }
    }
}
