﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BAL;
using DAL;
using Entity;
using Exceptions;
using WebApplication1.Models;
using System.Data;

namespace WebApplication1.Controllers
{
    public class EmployeeController : Controller
    {
        List<Models.Employee> emplist = new List<Models.Employee>();
        [HttpGet]
        public ActionResult HomePage()
        {
            return View();
        }

        // GET: Employee
        [HttpGet]
        public ActionResult AddEmpDetails()
        {
            try
            {
                int id = EmployeeBAL.employeid();
                return View(id);
            }
            catch (EmpDatabaseException ex)
            {
                ViewBag.message = ex.Message;
            }
            catch (EmpInvalidDataException ex)
            {
                ViewBag.message = ex.Message;
            }
            catch (Exception ex)
            {
                ViewBag.message = ex.Message;
            }

            return View();
        }



        [HttpPost]
        public ActionResult AddEmpDetails(Entity.Employee emp)
        {
            try
            {
                EmployeeBAL.SubmitDetails(emp);


            }
            catch (EmpDatabaseException ex)
            {
                ViewBag.message = ex.Message;
            }
            catch (EmpInvalidDataException ex)
            {
                ViewBag.message = ex.Message;
            }
            catch (Exception ex)
            {
                ViewBag.message = ex.Message;
            }

            return View();

        }

        [HttpGet]
        public ActionResult ViewDetails()
        {
            try
            {
                DataTable dt = new DataTable();

                dt = EmployeeBAL.RetrieveDetails();

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Models.Employee emp = new Models.Employee();
                    emp.EmpID = Convert.ToInt32(dt.Rows[i]["EmpID"]);
                    emp.Name = dt.Rows[i]["Name"].ToString();
                    emp.Gender = dt.Rows[i]["Gender"].ToString();
                    emp.Position = dt.Rows[i]["Position"].ToString();
                    emp.salary = Convert.ToInt32(dt.Rows[i]["Salary"]);
                    emplist.Add(emp);
                }
            }
            catch (EmpDatabaseException ex)
            {
                ViewBag.message = ex.Message;
            }
            catch (EmpInvalidDataException ex)
            {
                ViewBag.message = ex.Message;
            }
            catch (Exception ex)
            {
                ViewBag.message = ex.Message;
            }
            return View(emplist);
        }
    }
}