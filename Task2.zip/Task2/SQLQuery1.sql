use Training_23Jan19_Pune
go
create table Employeedata
(
EmpID int identity(1,1) primary key,
Name varchar(20) not null,
Gender varchar(6) not null,
Position varchar(30) not null,
Salary int not null
)

select * from Employeedata
drop table Employeedata
exec sp_help Employeedata



create procedure AddEmployee 
@Name varchar(20),
@Gender varchar(6),
@Position varchar(30),
@Salary int
as
begin
insert into Employeedata values 
(
@Name ,
@Gender ,
@Position ,
@Salary 
)
end
drop proc AddEmployee

create procedure FetchEmployees
as
begin
select * from Employeedata
end